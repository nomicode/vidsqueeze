import os
import sys
import time
import asyncio
from typing import Optional
from tqdm import tqdm
import ffmpeg
import re
import subprocess

from . import smartpath


def print_error(message):
    print(f"Error: {message}", file=sys.stderr)


def print_status(msg, details=""):
    out = "==> "
    if details:
        msg = f"{msg}:"
    out += msg
    if details:
        out += f" {details}"
    print(out)


def get_video_info(input_file):
    try:
        probe = ffmpeg.probe(input_file)
        video_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "video"),
            None,
        )
        if video_stream is None:
            raise Exception("No video stream found")

        fps = eval(video_stream["r_frame_rate"])
        duration = float(video_stream["duration"])
        total_frames = int(fps * duration)
        file_size = os.path.getsize(input_file)
        return total_frames, duration, file_size
    except ffmpeg.Error as e:
        print_error(f"Error probing video file: {e}")
        sys.exit(1)
    except Exception as e:
        print_error(f"An unexpected error occurred: {e}")
        sys.exit(1)


async def compress_video(
    input_file: str,
    output_file: str,
    no_audio: bool,
    resolution: Optional[str],
    fps: Optional[str],
    lossless: bool,
    quality: Optional[int],
    verbose: bool,
    very_verbose: bool,
):
    if verbose:
        print_status("Compressing video", input_file)

    try:
        total_frames, duration, file_size = get_video_info(input_file)
    except Exception as e:
        print_error(f"Error getting video info: {e}")
        return

    ffmpeg_cmd = [
        "ffmpeg",
        "-i",
        input_file,
        "-progress",
        "pipe:1",
        "-nostats",
    ]

    if no_audio:
        ffmpeg_cmd.extend(["-an"])
    else:
        ffmpeg_cmd.extend(["-c:a", "aac", "-b:a", "128k"])

    if resolution:
        scale_filter = {
            "4k": "scale=min(3840\\,iw):min(2160\\,ih):force_original_aspect_ratio=decrease",
            "1080p": "scale=min(1920\\,iw):min(1080\\,ih):force_original_aspect_ratio=decrease",
            "720p": "scale=min(1280\\,iw):min(720\\,ih):force_original_aspect_ratio=decrease",
            "576p": "scale=min(1024\\,iw):min(576\\,ih):force_original_aspect_ratio=decrease",
            "480p": "scale=min(854\\,iw):min(480\\,ih):force_original_aspect_ratio=decrease",
        }.get(resolution)
        if scale_filter:
            ffmpeg_cmd.extend(["-vf", scale_filter])

    if fps:
        fps_value = {"film": 24, "pal": 25, "ntsc": 30, "60fps": 60}.get(fps, fps)
        ffmpeg_cmd.extend(["-r", str(fps_value)])

    if lossless:
        ffmpeg_cmd.extend(["-c:v", "libx264", "-preset", "medium", "-crf", "0"])
    else:
        quality_value = quality if quality is not None else 23
        ffmpeg_cmd.extend(
            ["-c:v", "libx264", "-preset", "medium", "-crf", str(quality_value)]
        )

    ffmpeg_cmd.extend(["-y", output_file])

    if very_verbose:
        print_status("FFmpeg command", " ".join(ffmpeg_cmd), verbose=True)

    process = await asyncio.create_subprocess_exec(
        *ffmpeg_cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    start_time = time.time()

    basename = os.path.basename(input_file)
    pbar = tqdm(
        desc=basename,
        total=file_size,
        unit="B",
        unit_scale=True,
        unit_divisor=1024,
        bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]",
    )

    time_regex = re.compile(r"out_time_ms=(\d+)")
    async for line in process.stdout:
        line = line.decode()
        time_match = time_regex.search(line)
        if time_match:
            time_ms = int(time_match.group(1))
            progress = int(time_ms / (duration * 1000000) * file_size)
            pbar.update(progress - pbar.n)

    # Ensure the progress bar reaches 100%
    pbar.update(file_size - pbar.n)

    # Close the progress bar
    pbar.close()

    # Wait for the process to finish
    stdout, stderr = await process.communicate()

    # Calculate elapsed time and average speed
    elapsed_time = time.time() - start_time
    avg_speed = file_size / elapsed_time / 1024 / 1024  # MB/s

    # Display final statistics
    print(
        f"Compressed: {file_size/1024/1024:.1f}MB in {elapsed_time:.1f}s at {avg_speed:.1f}MB/s"
    )

    if process.returncode != 0:
        print_error("Encoding failed")
        print_error(f"FFmpeg error output:\n{stderr.decode()}")
        sys.exit(1)

    if verbose:
        print_status("Wrote", output_file)
